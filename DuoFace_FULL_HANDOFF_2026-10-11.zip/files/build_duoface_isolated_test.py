from pathlib import Path
import shutil,subprocess
src=Path('/mnt/data/duoface_work'); dst=Path('/mnt/data/duoface_isolated_test')
if dst.exists(): shutil.rmtree(dst)
shutil.copytree(src,dst)
ctl=dst/'DEBIAN/control'
ctl.write_text('''Package: com.duoface.app
Name: DuoFace
Version: 1.0.3-3
Architecture: iphoneos-arm64
Section: Tweaks
Maintainer: DuoFace Team
Author: DuoFace Team
Depends: mobilesubstrate (>= 0.9.5000), firmware (>= 13.0)
Description: DuoFace CarPlay split-screen experimental standalone package. Unsigned test build; runtime independence not verified.
Icon: file:///var/jb/Library/Application Support/DuoFace/duoface-icon.png
''')
# No legacy preference migration, daemon disabling, system log removal, or unbounded sudo privilege.
(dst/'DEBIAN/postinst').write_text('''#!/bin/sh
set -e
if command -v uicache >/dev/null 2>&1; then uicache -a 2>/dev/null || true; fi
exit 0
''')
(dst/'DEBIAN/prerm').write_text('#!/bin/sh\nexit 0\n')
for f in ['postinst','prerm']:(dst/'DEBIAN'/f).chmod(0o755)
(dst/'var/jb/etc/sudoers.d/duoface').unlink(missing_ok=True)
# Do not include OldABI because it is a shared global library owned by other tweaks.
(dst/'var/jb/usr/lib/ellekit/OldABI.dylib').unlink(missing_ok=True)
# Remove global helper binaries: can overwrite other packages; unresolved dependency flagged in audit.
(dst/'var/jb/usr/bin/cboptimize').unlink(missing_ok=True)
(dst/'var/jb/usr/libexec/cboptimize_helper').unlink(missing_ok=True)
out='/mnt/data/DuoFace_1.0.3-3_ISOLATED_UNVERIFIED.deb'
subprocess.run(['dpkg-deb','--build','--root-owner-group',str(dst),out],check=True)
print(out)

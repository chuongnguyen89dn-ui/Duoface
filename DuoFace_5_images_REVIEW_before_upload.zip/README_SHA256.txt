DUOFACE - 5 IMAGE REVIEW PACKAGE
Exactly five images, unchanged source bytes. No DEB resizing.
IMPORTANT: Only images 01 and 02 are confirmed approved originals.
03 is newly generated circular swap demo; 04 is design reference; 05 is existing picker asset.
Do not treat this ZIP as five approved/production-ready images.

01_DuoFace_icon_original.jpeg | 1254x1254 | 226299 bytes | SHA256 01f1b3d68a3ce4b5fc224035542fb7c16475eec60c3a94950a2c4993ba44c238 | User-uploaded approved icon
02_DuoFace_logo_layout_original.png | 1983x793 | 876637 bytes | SHA256 eb4646249ac0c2d05417d61013c68a76ffc5d7705d7823d5f570778cb45a5df9 | User-uploaded approved horizontal and vertical logos
03_Swap_round_button_demo.png | 1254x1254 | 1413443 bytes | SHA256 cddc0985f514b64574cf2717245e17df1e602d28a0ec985865869ece8493adeb | Circular swap button newly generated from user mockup; not yet approved
04_Fullscreen_button_design.png | 1254x1254 | 1022504 bytes | SHA256 51c261268493393003eeb77636b4b9813abb908dba8a0359c56b41b5f371f125 | Fullscreen four-corners button design reference
05_Picker_button.png | 256x70 | 15225 bytes | SHA256 16a959b71a0d3d8ef86e2ac9163024af457aec180770c757fe4b16d2b0a85f8a | Existing picker button asset; not separately approved

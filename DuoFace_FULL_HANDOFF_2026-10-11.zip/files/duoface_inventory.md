# DuoFace / DuoNavi — kiểm kê DEB cục bộ

Kiểm kê được tạo trực tiếp từ các file hiện có trong phiên làm việc 2026-10-11. Chưa phải bằng chứng các DEB đã upload GitHub.

## `DuoFace_1.0.3-2_REPLACES_OLD_UNSIGNED_TEST.deb`
- Bytes: 1848976
- SHA-256: `c39ccebff6ffdfaf22470a147e527e80d240209ee933fde41328d333b8629859`
- Package: `com.duoface.app`
- Version: `1.0.3-2`
- Architecture: `iphoneos-arm64`

<details><summary>Payload files (dpkg-deb -c)</summary>

```text
drwxrwxrwx root/root         0 2026-10-11 08:12 ./
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/
drwxr-xr-x root/root         0 2026-10-11 08:12 ./var/jb/Applications/
drwxrwxrwx root/root         0 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/
-rwxrwxrwx root/root      1610 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon29x29.png
-rwxrwxrwx root/root      4908 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon29x29@2x.png
-rwxrwxrwx root/root      9510 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon29x29@3x.png
-rwxrwxrwx root/root      2666 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon40x40.png
-rwxrwxrwx root/root      8308 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon40x40@2x.png
-rwxrwxrwx root/root     15912 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon40x40@3x.png
-rwxrwxrwx root/root      3846 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon50x50.png
-rwxrwxrwx root/root     11881 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon50x50@2x.png
-rwxrwxrwx root/root      4817 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon57x57.png
-rwxrwxrwx root/root     14679 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon57x57@2x.png
-rwxrwxrwx root/root     28640 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon57x57@3x.png
-rwxrwxrwx root/root      5170 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon60x60.png
-rwxrwxrwx root/root     15912 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon60x60@2x.png
-rwxrwxrwx root/root     31127 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon60x60@3x.png
-rwxrwxrwx root/root      7019 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon72x72.png
-rwxrwxrwx root/root     21518 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon72x72@2x.png
-rwxrwxrwx root/root      7644 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon76x76.png
-rwxrwxrwx root/root     23455 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon76x76@2x.png
-rwxrwxrwx root/root   2456784 2026-10-11 08:13 ./var/jb/Applications/DuoFaceUI.app/DuoFaceUI
-rwxrwxrwx root/root      2303 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/Info.plist
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/Library/
drwxrwxrwx root/root         0 2026-10-11 08:12 ./var/jb/Library/Application Support/
drwxrwxrwx root/root         0 2026-10-11 08:12 ./var/jb/Library/Application Support/DuoFace/
-rwxrwxrwx root/root     59016 2026-10-11 08:12 ./var/jb/Library/Application Support/DuoFace/duoface-icon.png
-rwxrwxrwx root/root    288627 2026-10-11 08:12 ./var/jb/Library/Application Support/DuoFace/duoface-logo-vert.png
-rwxrwxrwx root/root    113061 2026-10-11 08:12 ./var/jb/Library/Application Support/DuoFace/duoface-logo.png
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/Library/MobileSubstrate/
drwxr-xr-x root/root         0 2026-10-11 08:12 ./var/jb/Library/MobileSubstrate/DynamicLibraries/
-rwxrwxrwx root/root   7540464 2026-10-11 08:13 ./var/jb/Library/MobileSubstrate/DynamicLibraries/DuoFaceDashboard.dylib
-rwxrwxrwx root/root      1446 2026-10-11 08:12 ./var/jb/Library/MobileSubstrate/DynamicLibraries/DuoFaceDashboard.plist
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/etc/
drwxrwxrwx root/root         0 2026-10-11 08:12 ./var/jb/etc/sudoers.d/
-rwxrwxrwx root/root        28 2026-09-30 03:20 ./var/jb/etc/sudoers.d/duoface
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/usr/
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/usr/bin/
-rwxrwxrwx root/root      3364 2026-10-11 08:12 ./var/jb/usr/bin/cboptimize
drwxrwxrwx root/root         0 2026-09-29 15:43 ./var/jb/usr/lib/
drwxrwxrwx root/root         0 2026-10-01 07:31 ./var/jb/usr/lib/ellekit/
-rwxrwxrwx root/root     67552 2026-10-01 07:31 ./var/jb/usr/lib/ellekit/OldABI.dylib
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/usr/libexec/
-rwxrwxrwx root/root    150528 2026-10-01 07:33 ./var/jb/usr/libexec/cboptimize_helper
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/mobile/
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/mobile/Library/
drwxr-xr-x root/root         0 2026-10-11 08:12 ./var/mobile/Library/Preferences/
-rw-r--r-- root/root       190 2026-10-11 07:31 ./var/mobile/Library/Preferences/com.duoface.sync.plist
```

</details>

## `DuoFace_1.0.3-3_ISOLATED_UNVERIFIED.deb`
- Bytes: 1841068
- SHA-256: `94602964a86753cc19e9747d2807f3d22b61e5a95f618a6e30b67ed81c59ff07`
- Package: `com.duoface.app`
- Version: `1.0.3-3`
- Architecture: `iphoneos-arm64`

<details><summary>Payload files (dpkg-deb -c)</summary>

```text
drwxrwxrwx root/root         0 2026-10-11 08:12 ./
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/
drwxr-xr-x root/root         0 2026-10-11 08:12 ./var/jb/Applications/
drwxrwxrwx root/root         0 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/
-rwxrwxrwx root/root      1610 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon29x29.png
-rwxrwxrwx root/root      4908 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon29x29@2x.png
-rwxrwxrwx root/root      9510 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon29x29@3x.png
-rwxrwxrwx root/root      2666 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon40x40.png
-rwxrwxrwx root/root      8308 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon40x40@2x.png
-rwxrwxrwx root/root     15912 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon40x40@3x.png
-rwxrwxrwx root/root      3846 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon50x50.png
-rwxrwxrwx root/root     11881 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon50x50@2x.png
-rwxrwxrwx root/root      4817 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon57x57.png
-rwxrwxrwx root/root     14679 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon57x57@2x.png
-rwxrwxrwx root/root     28640 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon57x57@3x.png
-rwxrwxrwx root/root      5170 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon60x60.png
-rwxrwxrwx root/root     15912 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon60x60@2x.png
-rwxrwxrwx root/root     31127 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon60x60@3x.png
-rwxrwxrwx root/root      7019 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon72x72.png
-rwxrwxrwx root/root     21518 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon72x72@2x.png
-rwxrwxrwx root/root      7644 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon76x76.png
-rwxrwxrwx root/root     23455 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon76x76@2x.png
-rwxrwxrwx root/root   2456784 2026-10-11 08:13 ./var/jb/Applications/DuoFaceUI.app/DuoFaceUI
-rwxrwxrwx root/root      2303 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/Info.plist
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/Library/
drwxrwxrwx root/root         0 2026-10-11 08:12 ./var/jb/Library/Application Support/
drwxrwxrwx root/root         0 2026-10-11 08:12 ./var/jb/Library/Application Support/DuoFace/
-rwxrwxrwx root/root     59016 2026-10-11 08:12 ./var/jb/Library/Application Support/DuoFace/duoface-icon.png
-rwxrwxrwx root/root    288627 2026-10-11 08:12 ./var/jb/Library/Application Support/DuoFace/duoface-logo-vert.png
-rwxrwxrwx root/root    113061 2026-10-11 08:12 ./var/jb/Library/Application Support/DuoFace/duoface-logo.png
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/Library/MobileSubstrate/
drwxr-xr-x root/root         0 2026-10-11 08:12 ./var/jb/Library/MobileSubstrate/DynamicLibraries/
-rwxrwxrwx root/root   7540464 2026-10-11 08:13 ./var/jb/Library/MobileSubstrate/DynamicLibraries/DuoFaceDashboard.dylib
-rwxrwxrwx root/root      1446 2026-10-11 08:12 ./var/jb/Library/MobileSubstrate/DynamicLibraries/DuoFaceDashboard.plist
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/etc/
drwxrwxrwx root/root         0 2026-10-11 08:25 ./var/jb/etc/sudoers.d/
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/usr/
drwxrwxrwx root/root         0 2026-10-11 08:25 ./var/jb/usr/bin/
drwxrwxrwx root/root         0 2026-09-29 15:43 ./var/jb/usr/lib/
drwxrwxrwx root/root         0 2026-10-11 08:25 ./var/jb/usr/lib/ellekit/
drwxr-xr-x root/root         0 2026-10-11 08:25 ./var/jb/usr/libexec/
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/mobile/
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/mobile/Library/
drwxr-xr-x root/root         0 2026-10-11 08:12 ./var/mobile/Library/Preferences/
-rw-r--r-- root/root       190 2026-10-11 07:31 ./var/mobile/Library/Preferences/com.duoface.sync.plist
```

</details>

## `DuoFace_1.0.3-4_FULL_COPY_UNSIGNED_TEST.deb`
- Bytes: 1848932
- SHA-256: `0fbff6ca5c6f262606d1381dd93feecdfbd536fffc1f3d9f4b09914486713c80`
- Package: `com.duoface.app`
- Version: `1.0.3-4`
- Architecture: `iphoneos-arm64`

<details><summary>Payload files (dpkg-deb -c)</summary>

```text
drwxrwxrwx root/root         0 2026-10-11 08:29 ./
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/
drwxr-xr-x root/root         0 2026-10-11 08:30 ./var/jb/Applications/
drwxrwxrwx root/root         0 2026-10-11 08:30 ./var/jb/Applications/DuoFaceUI.app/
-rwxrwxrwx root/root      1610 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon29x29.png
-rwxrwxrwx root/root      4908 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon29x29@2x.png
-rwxrwxrwx root/root      9510 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon29x29@3x.png
-rwxrwxrwx root/root      2666 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon40x40.png
-rwxrwxrwx root/root      8308 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon40x40@2x.png
-rwxrwxrwx root/root     15912 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon40x40@3x.png
-rwxrwxrwx root/root      3846 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon50x50.png
-rwxrwxrwx root/root     11881 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon50x50@2x.png
-rwxrwxrwx root/root      4817 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon57x57.png
-rwxrwxrwx root/root     14679 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon57x57@2x.png
-rwxrwxrwx root/root     28640 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon57x57@3x.png
-rwxrwxrwx root/root      5170 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon60x60.png
-rwxrwxrwx root/root     15912 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon60x60@2x.png
-rwxrwxrwx root/root     31127 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon60x60@3x.png
-rwxrwxrwx root/root      7019 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon72x72.png
-rwxrwxrwx root/root     21518 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon72x72@2x.png
-rwxrwxrwx root/root      7644 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon76x76.png
-rwxrwxrwx root/root     23455 2026-10-11 08:29 ./var/jb/Applications/DuoFaceUI.app/AppIcon76x76@2x.png
-rwxrwxrwx root/root   2456784 2026-10-11 08:30 ./var/jb/Applications/DuoFaceUI.app/DuoFaceUI
-rwxrwxrwx root/root      2303 2026-10-11 08:30 ./var/jb/Applications/DuoFaceUI.app/Info.plist
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/Library/
drwxrwxrwx root/root         0 2026-10-11 08:30 ./var/jb/Library/Application Support/
drwxrwxrwx root/root         0 2026-10-11 08:30 ./var/jb/Library/Application Support/DuoFace/
-rwxrwxrwx root/root     59016 2026-10-11 08:29 ./var/jb/Library/Application Support/DuoFace/duoface-icon.png
-rwxrwxrwx root/root    288627 2026-10-11 08:29 ./var/jb/Library/Application Support/DuoFace/duoface-logo-vert.png
-rwxrwxrwx root/root    113061 2026-10-11 08:29 ./var/jb/Library/Application Support/DuoFace/duoface-logo.png
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/Library/MobileSubstrate/
drwxr-xr-x root/root         0 2026-10-11 08:30 ./var/jb/Library/MobileSubstrate/DynamicLibraries/
-rwxrwxrwx root/root   7540464 2026-10-11 08:30 ./var/jb/Library/MobileSubstrate/DynamicLibraries/DuoFaceDashboard.dylib
-rwxrwxrwx root/root      1446 2026-10-11 08:30 ./var/jb/Library/MobileSubstrate/DynamicLibraries/DuoFaceDashboard.plist
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/etc/
drwxrwxrwx root/root         0 2026-10-11 08:30 ./var/jb/etc/sudoers.d/
-rwxrwxrwx root/root        28 2026-09-30 03:20 ./var/jb/etc/sudoers.d/duoface
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/usr/
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/usr/bin/
-rwxrwxrwx root/root      3364 2026-10-11 08:30 ./var/jb/usr/bin/cboptimize
drwxrwxrwx root/root         0 2026-09-29 15:43 ./var/jb/usr/lib/
drwxrwxrwx root/root         0 2026-10-01 07:31 ./var/jb/usr/lib/ellekit/
-rwxrwxrwx root/root     67552 2026-10-01 07:31 ./var/jb/usr/lib/ellekit/OldABI.dylib
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/usr/libexec/
-rwxrwxrwx root/root    150528 2026-10-01 07:33 ./var/jb/usr/libexec/cboptimize_helper
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/mobile/
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/mobile/Library/
drwxr-xr-x root/root         0 2026-10-11 08:30 ./var/mobile/Library/Preferences/
-rw-r--r-- root/root       190 2026-10-11 07:31 ./var/mobile/Library/Preferences/com.duoface.sync.plist
```

</details>

## `DuoFace_1.0.3-5_ROOTLESS_SAFE_TEST.deb`
- Bytes: 1838460
- SHA-256: `6d2aefa3db144740c0ab6bbd655b78ed2e3e6285350c30dba15480485006526e`
- Package: `com.duoface.app`
- Version: `1.0.3-5`
- Architecture: `iphoneos-arm64`

<details><summary>Payload files (dpkg-deb -c)</summary>

```text
drwxr-sr-x root/root         0 2026-10-11 09:01 ./
drwxr-sr-x root/root         0 2026-10-11 09:01 ./Applications/
drwxrwxrwx root/root         0 2026-10-11 08:30 ./Applications/DuoFaceUI.app/
-rw-r--r-- root/root      1610 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon29x29.png
-rw-r--r-- root/root      4908 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon29x29@2x.png
-rw-r--r-- root/root      9510 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon29x29@3x.png
-rw-r--r-- root/root      2666 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon40x40.png
-rw-r--r-- root/root      8308 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon40x40@2x.png
-rw-r--r-- root/root     15912 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon40x40@3x.png
-rw-r--r-- root/root      3846 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon50x50.png
-rw-r--r-- root/root     11881 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon50x50@2x.png
-rw-r--r-- root/root      4817 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon57x57.png
-rw-r--r-- root/root     14679 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon57x57@2x.png
-rw-r--r-- root/root     28640 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon57x57@3x.png
-rw-r--r-- root/root      5170 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon60x60.png
-rw-r--r-- root/root     15912 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon60x60@2x.png
-rw-r--r-- root/root     31127 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon60x60@3x.png
-rw-r--r-- root/root      7019 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon72x72.png
-rw-r--r-- root/root     21518 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon72x72@2x.png
-rw-r--r-- root/root      7644 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon76x76.png
-rw-r--r-- root/root     23455 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon76x76@2x.png
-rwxrwxrwx root/root   2456784 2026-10-11 08:30 ./Applications/DuoFaceUI.app/DuoFaceUI
-rw-r--r-- root/root      2303 2026-10-11 08:30 ./Applications/DuoFaceUI.app/Info.plist
drwxr-sr-x root/root         0 2026-10-11 09:01 ./Library/
drwxr-sr-x root/root         0 2026-10-11 09:01 ./Library/Application Support/
drwxrwxrwx root/root         0 2026-10-11 08:30 ./Library/Application Support/DuoFace/
-rw-r--r-- root/root     59016 2026-10-11 08:29 ./Library/Application Support/DuoFace/duoface-icon.png
-rw-r--r-- root/root    288627 2026-10-11 08:29 ./Library/Application Support/DuoFace/duoface-logo-vert.png
-rw-r--r-- root/root    113061 2026-10-11 08:29 ./Library/Application Support/DuoFace/duoface-logo.png
drwxr-sr-x root/root         0 2026-10-11 09:01 ./Library/MobileSubstrate/
drwxr-xr-x root/root         0 2026-10-11 08:30 ./Library/MobileSubstrate/DynamicLibraries/
-rwxrwxrwx root/root   7540464 2026-10-11 08:30 ./Library/MobileSubstrate/DynamicLibraries/DuoFaceDashboard.dylib
-rw-r--r-- root/root      1446 2026-10-11 08:30 ./Library/MobileSubstrate/DynamicLibraries/DuoFaceDashboard.plist
```

</details>

## `DuoFace_1.0.3-6_FULL_PAYLOAD_ROOTLESS_UNVERIFIED.deb`
- Bytes: 1846956
- SHA-256: `2120480166170c5f71b12a595bed7a5ab892fbd84038ef878eca8e8243062e9a`
- Package: `com.duoface.app`
- Version: `1.0.3-6`
- Architecture: `iphoneos-arm64`

<details><summary>Payload files (dpkg-deb -c)</summary>

```text
drwxrwxrwx root/root         0 2026-10-11 09:19 ./
drwxr-xr-x root/root         0 2026-10-11 08:30 ./Applications/
drwxr-xr-x root/root         0 2026-10-11 08:30 ./Applications/DuoFaceUI.app/
-rw-r--r-- root/root      1610 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon29x29.png
-rw-r--r-- root/root      4908 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon29x29@2x.png
-rw-r--r-- root/root      9510 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon29x29@3x.png
-rw-r--r-- root/root      2666 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon40x40.png
-rw-r--r-- root/root      8308 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon40x40@2x.png
-rw-r--r-- root/root     15912 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon40x40@3x.png
-rw-r--r-- root/root      3846 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon50x50.png
-rw-r--r-- root/root     11881 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon50x50@2x.png
-rw-r--r-- root/root      4817 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon57x57.png
-rw-r--r-- root/root     14679 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon57x57@2x.png
-rw-r--r-- root/root     28640 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon57x57@3x.png
-rw-r--r-- root/root      5170 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon60x60.png
-rw-r--r-- root/root     15912 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon60x60@2x.png
-rw-r--r-- root/root     31127 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon60x60@3x.png
-rw-r--r-- root/root      7019 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon72x72.png
-rw-r--r-- root/root     21518 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon72x72@2x.png
-rw-r--r-- root/root      7644 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon76x76.png
-rw-r--r-- root/root     23455 2026-10-11 08:29 ./Applications/DuoFaceUI.app/AppIcon76x76@2x.png
-rwxr-xr-x root/root   2456784 2026-10-11 08:30 ./Applications/DuoFaceUI.app/DuoFaceUI
-rw-r--r-- root/root      2303 2026-10-11 08:30 ./Applications/DuoFaceUI.app/Info.plist
drwxr-xr-x root/root         0 2026-10-01 07:33 ./Library/
drwxr-xr-x root/root         0 2026-10-11 08:30 ./Library/Application Support/
drwxr-xr-x root/root         0 2026-10-11 08:30 ./Library/Application Support/DuoFace/
-rw-r--r-- root/root     59016 2026-10-11 08:29 ./Library/Application Support/DuoFace/duoface-icon.png
-rw-r--r-- root/root    288627 2026-10-11 08:29 ./Library/Application Support/DuoFace/duoface-logo-vert.png
-rw-r--r-- root/root    113061 2026-10-11 08:29 ./Library/Application Support/DuoFace/duoface-logo.png
drwxr-xr-x root/root         0 2026-10-01 07:33 ./Library/MobileSubstrate/
drwxr-xr-x root/root         0 2026-10-11 08:30 ./Library/MobileSubstrate/DynamicLibraries/
-rwxr-xr-x root/root   7540464 2026-10-11 08:30 ./Library/MobileSubstrate/DynamicLibraries/DuoFaceDashboard.dylib
-rw-r--r-- root/root      1446 2026-10-11 08:30 ./Library/MobileSubstrate/DynamicLibraries/DuoFaceDashboard.plist
drwxr-xr-x root/root         0 2026-09-30 03:20 ./etc/
drwxr-xr-x root/root         0 2026-10-11 08:30 ./etc/sudoers.d/
-rw-r--r-- root/root        28 2026-09-30 03:20 ./etc/sudoers.d/duoface
drwxr-xr-x root/root         0 2026-10-01 07:33 ./usr/
drwxr-xr-x root/root         0 2026-09-30 03:20 ./usr/bin/
-rwxr-xr-x root/root      3364 2026-10-11 08:30 ./usr/bin/cboptimize
drwxr-xr-x root/root         0 2026-09-29 15:43 ./usr/lib/
drwxr-xr-x root/root         0 2026-10-01 07:31 ./usr/lib/ellekit/
-rwxr-xr-x root/root     67552 2026-10-01 07:31 ./usr/lib/ellekit/OldABI.dylib
drwxr-xr-x root/root         0 2026-10-01 07:33 ./usr/libexec/
-rwxr-xr-x root/root    150528 2026-10-01 07:33 ./usr/libexec/cboptimize_helper
```

</details>

## `DuoFace_1.0.3_REBRAND_UNSIGNED_TEST.deb`
- Bytes: 1848964
- SHA-256: `5fe97aa2bd6d058746c60b54b3c9fb3c401d97fa5a3a032e0db828a115e75038`
- Package: `com.duoface.app`
- Version: `1.0.3`
- Architecture: `iphoneos-arm64`

<details><summary>Payload files (dpkg-deb -c)</summary>

```text
drwxrwxrwx root/root         0 2026-10-11 08:12 ./
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/
drwxr-xr-x root/root         0 2026-10-11 08:12 ./var/jb/Applications/
drwxrwxrwx root/root         0 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/
-rwxrwxrwx root/root      1610 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon29x29.png
-rwxrwxrwx root/root      4908 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon29x29@2x.png
-rwxrwxrwx root/root      9510 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon29x29@3x.png
-rwxrwxrwx root/root      2666 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon40x40.png
-rwxrwxrwx root/root      8308 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon40x40@2x.png
-rwxrwxrwx root/root     15912 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon40x40@3x.png
-rwxrwxrwx root/root      3846 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon50x50.png
-rwxrwxrwx root/root     11881 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon50x50@2x.png
-rwxrwxrwx root/root      4817 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon57x57.png
-rwxrwxrwx root/root     14679 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon57x57@2x.png
-rwxrwxrwx root/root     28640 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon57x57@3x.png
-rwxrwxrwx root/root      5170 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon60x60.png
-rwxrwxrwx root/root     15912 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon60x60@2x.png
-rwxrwxrwx root/root     31127 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon60x60@3x.png
-rwxrwxrwx root/root      7019 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon72x72.png
-rwxrwxrwx root/root     21518 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon72x72@2x.png
-rwxrwxrwx root/root      7644 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon76x76.png
-rwxrwxrwx root/root     23455 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/AppIcon76x76@2x.png
-rwxrwxrwx root/root   2456784 2026-10-11 08:13 ./var/jb/Applications/DuoFaceUI.app/DuoFaceUI
-rwxrwxrwx root/root      2303 2026-10-11 08:12 ./var/jb/Applications/DuoFaceUI.app/Info.plist
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/Library/
drwxrwxrwx root/root         0 2026-10-11 08:12 ./var/jb/Library/Application Support/
drwxrwxrwx root/root         0 2026-10-11 08:12 ./var/jb/Library/Application Support/DuoFace/
-rwxrwxrwx root/root     59016 2026-10-11 08:12 ./var/jb/Library/Application Support/DuoFace/duoface-icon.png
-rwxrwxrwx root/root    288627 2026-10-11 08:12 ./var/jb/Library/Application Support/DuoFace/duoface-logo-vert.png
-rwxrwxrwx root/root    113061 2026-10-11 08:12 ./var/jb/Library/Application Support/DuoFace/duoface-logo.png
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/Library/MobileSubstrate/
drwxr-xr-x root/root         0 2026-10-11 08:12 ./var/jb/Library/MobileSubstrate/DynamicLibraries/
-rwxrwxrwx root/root   7540464 2026-10-11 08:13 ./var/jb/Library/MobileSubstrate/DynamicLibraries/DuoFaceDashboard.dylib
-rwxrwxrwx root/root      1446 2026-10-11 08:12 ./var/jb/Library/MobileSubstrate/DynamicLibraries/DuoFaceDashboard.plist
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/etc/
drwxrwxrwx root/root         0 2026-10-11 08:12 ./var/jb/etc/sudoers.d/
-rwxrwxrwx root/root        28 2026-09-30 03:20 ./var/jb/etc/sudoers.d/duoface
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/usr/
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/usr/bin/
-rwxrwxrwx root/root      3364 2026-10-11 08:12 ./var/jb/usr/bin/cboptimize
drwxrwxrwx root/root         0 2026-09-29 15:43 ./var/jb/usr/lib/
drwxrwxrwx root/root         0 2026-10-01 07:31 ./var/jb/usr/lib/ellekit/
-rwxrwxrwx root/root     67552 2026-10-01 07:31 ./var/jb/usr/lib/ellekit/OldABI.dylib
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/usr/libexec/
-rwxrwxrwx root/root    150528 2026-10-01 07:33 ./var/jb/usr/libexec/cboptimize_helper
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/mobile/
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/mobile/Library/
drwxr-xr-x root/root         0 2026-10-11 08:12 ./var/mobile/Library/Preferences/
-rw-r--r-- root/root       190 2026-10-11 07:31 ./var/mobile/Library/Preferences/com.duoface.sync.plist
```

</details>

## `DuoNavi_1.0.3_39day_LOCAL_TEST_UNSIGNED.deb`
- Bytes: 1390000
- SHA-256: `4f5b8ccda0db63ddc55decc4168ff2c1f2ef4218695ad411a7a1f622ff733011`
- Package: `com.duonavi.app`
- Version: `1.0.3`
- Architecture: `iphoneos-arm64`

<details><summary>Payload files (dpkg-deb -c)</summary>

```text
drwxrwxrwx root/root         0 2026-10-11 07:07 ./
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/Applications/
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/Applications/DuoNaviUI.app/
-rwxrwxrwx root/root      1683 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon29x29.png
-rwxrwxrwx root/root      4418 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon29x29@2x.png
-rwxrwxrwx root/root      6962 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon29x29@3x.png
-rwxrwxrwx root/root      2558 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon40x40.png
-rwxrwxrwx root/root      6442 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon40x40@2x.png
-rwxrwxrwx root/root     11080 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon40x40@3x.png
-rwxrwxrwx root/root      3512 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon50x50.png
-rwxrwxrwx root/root      8772 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon50x50@2x.png
-rwxrwxrwx root/root      4310 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon57x57.png
-rwxrwxrwx root/root     10259 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon57x57@2x.png
-rwxrwxrwx root/root     16921 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon57x57@3x.png
-rwxrwxrwx root/root      4569 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon60x60.png
-rwxrwxrwx root/root     11080 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon60x60@2x.png
-rwxrwxrwx root/root     19030 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon60x60@3x.png
-rwxrwxrwx root/root      5677 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon72x72.png
-rwxrwxrwx root/root     14138 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon72x72@2x.png
-rwxrwxrwx root/root      6072 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon76x76.png
-rwxrwxrwx root/root     14885 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon76x76@2x.png
-rwxrwxrwx root/root   2456784 2026-10-01 07:33 ./var/jb/Applications/DuoNaviUI.app/DuoNaviUI
-rwxrwxrwx root/root      2303 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/Info.plist
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/Library/
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/Library/Application Support/
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/Library/Application Support/DuoNavi/
-rwxrwxrwx root/root     19601 2026-09-30 03:20 ./var/jb/Library/Application Support/DuoNavi/duonavi-icon.png
-rwxrwxrwx root/root     22348 2026-09-30 03:20 ./var/jb/Library/Application Support/DuoNavi/duonavi-logo-vert.png
-rwxrwxrwx root/root     22203 2026-09-30 03:20 ./var/jb/Library/Application Support/DuoNavi/duonavi-logo.png
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/Library/MobileSubstrate/
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/Library/MobileSubstrate/DynamicLibraries/
-rwxrwxrwx root/root   7540464 2026-10-01 07:33 ./var/jb/Library/MobileSubstrate/DynamicLibraries/DuoNaviDashboard.dylib
-rwxrwxrwx root/root      1446 2026-10-01 07:33 ./var/jb/Library/MobileSubstrate/DynamicLibraries/DuoNaviDashboard.plist
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/etc/
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/etc/sudoers.d/
-rwxrwxrwx root/root        28 2026-09-30 03:20 ./var/jb/etc/sudoers.d/duonavi
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/usr/
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/usr/bin/
-rwxrwxrwx root/root      3364 2026-09-30 03:20 ./var/jb/usr/bin/cboptimize
drwxrwxrwx root/root         0 2026-09-29 15:43 ./var/jb/usr/lib/
drwxrwxrwx root/root         0 2026-10-01 07:31 ./var/jb/usr/lib/ellekit/
-rwxrwxrwx root/root     67552 2026-10-01 07:31 ./var/jb/usr/lib/ellekit/OldABI.dylib
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/usr/libexec/
-rwxrwxrwx root/root    150528 2026-10-01 07:33 ./var/jb/usr/libexec/cboptimize_helper
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/mobile/
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/mobile/Library/
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/mobile/Library/Preferences/
-rw-r--r-- root/root       190 2026-10-11 07:07 ./var/mobile/Library/Preferences/com.duonavi.sync.plist
```

</details>

## `DuoNavi_1.0.3_5years_UNSIGNED_TEST.deb`
- Bytes: 1389692
- SHA-256: `67ca87cf92a2383ea3b5fc35e7e59fb0ecf292956eb359f4e898510eb027306a`
- Package: `com.duonavi.app`
- Version: `1.0.3`
- Architecture: `iphoneos-arm64`

<details><summary>Payload files (dpkg-deb -c)</summary>

```text
drwxrwxrwx root/root         0 2026-10-11 07:31 ./
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/Applications/
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/Applications/DuoNaviUI.app/
-rwxrwxrwx root/root      1683 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon29x29.png
-rwxrwxrwx root/root      4418 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon29x29@2x.png
-rwxrwxrwx root/root      6962 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon29x29@3x.png
-rwxrwxrwx root/root      2558 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon40x40.png
-rwxrwxrwx root/root      6442 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon40x40@2x.png
-rwxrwxrwx root/root     11080 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon40x40@3x.png
-rwxrwxrwx root/root      3512 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon50x50.png
-rwxrwxrwx root/root      8772 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon50x50@2x.png
-rwxrwxrwx root/root      4310 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon57x57.png
-rwxrwxrwx root/root     10259 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon57x57@2x.png
-rwxrwxrwx root/root     16921 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon57x57@3x.png
-rwxrwxrwx root/root      4569 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon60x60.png
-rwxrwxrwx root/root     11080 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon60x60@2x.png
-rwxrwxrwx root/root     19030 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon60x60@3x.png
-rwxrwxrwx root/root      5677 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon72x72.png
-rwxrwxrwx root/root     14138 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon72x72@2x.png
-rwxrwxrwx root/root      6072 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon76x76.png
-rwxrwxrwx root/root     14885 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon76x76@2x.png
-rwxrwxrwx root/root   2456784 2026-10-01 07:33 ./var/jb/Applications/DuoNaviUI.app/DuoNaviUI
-rwxrwxrwx root/root      2303 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/Info.plist
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/Library/
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/Library/Application Support/
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/Library/Application Support/DuoNavi/
-rwxrwxrwx root/root     19601 2026-09-30 03:20 ./var/jb/Library/Application Support/DuoNavi/duonavi-icon.png
-rwxrwxrwx root/root     22348 2026-09-30 03:20 ./var/jb/Library/Application Support/DuoNavi/duonavi-logo-vert.png
-rwxrwxrwx root/root     22203 2026-09-30 03:20 ./var/jb/Library/Application Support/DuoNavi/duonavi-logo.png
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/Library/MobileSubstrate/
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/Library/MobileSubstrate/DynamicLibraries/
-rwxrwxrwx root/root   7540464 2026-10-01 07:33 ./var/jb/Library/MobileSubstrate/DynamicLibraries/DuoNaviDashboard.dylib
-rwxrwxrwx root/root      1446 2026-10-01 07:33 ./var/jb/Library/MobileSubstrate/DynamicLibraries/DuoNaviDashboard.plist
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/etc/
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/etc/sudoers.d/
-rwxrwxrwx root/root        28 2026-09-30 03:20 ./var/jb/etc/sudoers.d/duonavi
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/usr/
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/usr/bin/
-rwxrwxrwx root/root      3364 2026-09-30 03:20 ./var/jb/usr/bin/cboptimize
drwxrwxrwx root/root         0 2026-09-29 15:43 ./var/jb/usr/lib/
drwxrwxrwx root/root         0 2026-10-01 07:31 ./var/jb/usr/lib/ellekit/
-rwxrwxrwx root/root     67552 2026-10-01 07:31 ./var/jb/usr/lib/ellekit/OldABI.dylib
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/usr/libexec/
-rwxrwxrwx root/root    150528 2026-10-01 07:33 ./var/jb/usr/libexec/cboptimize_helper
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/mobile/
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/mobile/Library/
drwxr-xr-x root/root         0 2026-10-11 07:07 ./var/mobile/Library/Preferences/
-rw-r--r-- root/root       190 2026-10-11 07:31 ./var/mobile/Library/Preferences/com.duonavi.sync.plist
```

</details>

## `DuoNavi_1.0.3_license_patch_UNSIGNED_TEST.deb`
- Bytes: 1389740
- SHA-256: `ce652393afaec028877d7d0626b9c931427db65f5df6156fcef78766f3b3ba22`
- Package: `com.duonavi.app`
- Version: `1.0.3`
- Architecture: `iphoneos-arm64`

<details><summary>Payload files (dpkg-deb -c)</summary>

```text
drwxrwxrwx root/root         0 2026-10-11 07:06 ./
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/Applications/
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/Applications/DuoNaviUI.app/
-rwxrwxrwx root/root      1683 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon29x29.png
-rwxrwxrwx root/root      4418 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon29x29@2x.png
-rwxrwxrwx root/root      6962 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon29x29@3x.png
-rwxrwxrwx root/root      2558 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon40x40.png
-rwxrwxrwx root/root      6442 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon40x40@2x.png
-rwxrwxrwx root/root     11080 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon40x40@3x.png
-rwxrwxrwx root/root      3512 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon50x50.png
-rwxrwxrwx root/root      8772 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon50x50@2x.png
-rwxrwxrwx root/root      4310 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon57x57.png
-rwxrwxrwx root/root     10259 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon57x57@2x.png
-rwxrwxrwx root/root     16921 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon57x57@3x.png
-rwxrwxrwx root/root      4569 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon60x60.png
-rwxrwxrwx root/root     11080 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon60x60@2x.png
-rwxrwxrwx root/root     19030 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon60x60@3x.png
-rwxrwxrwx root/root      5677 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon72x72.png
-rwxrwxrwx root/root     14138 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon72x72@2x.png
-rwxrwxrwx root/root      6072 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon76x76.png
-rwxrwxrwx root/root     14885 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/AppIcon76x76@2x.png
-rwxrwxrwx root/root   2456784 2026-10-01 07:33 ./var/jb/Applications/DuoNaviUI.app/DuoNaviUI
-rwxrwxrwx root/root      2303 2026-10-01 06:31 ./var/jb/Applications/DuoNaviUI.app/Info.plist
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/Library/
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/Library/Application Support/
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/Library/Application Support/DuoNavi/
-rwxrwxrwx root/root     19601 2026-09-30 03:20 ./var/jb/Library/Application Support/DuoNavi/duonavi-icon.png
-rwxrwxrwx root/root     22348 2026-09-30 03:20 ./var/jb/Library/Application Support/DuoNavi/duonavi-logo-vert.png
-rwxrwxrwx root/root     22203 2026-09-30 03:20 ./var/jb/Library/Application Support/DuoNavi/duonavi-logo.png
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/Library/MobileSubstrate/
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/Library/MobileSubstrate/DynamicLibraries/
-rwxrwxrwx root/root   7540464 2026-10-11 07:06 ./var/jb/Library/MobileSubstrate/DynamicLibraries/DuoNaviDashboard.dylib
-rwxrwxrwx root/root      1446 2026-10-01 07:33 ./var/jb/Library/MobileSubstrate/DynamicLibraries/DuoNaviDashboard.plist
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/etc/
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/etc/sudoers.d/
-rwxrwxrwx root/root        28 2026-09-30 03:20 ./var/jb/etc/sudoers.d/duonavi
drwxrwxrwx root/root         0 2026-10-01 07:33 ./var/jb/usr/
drwxrwxrwx root/root         0 2026-09-30 03:20 ./var/jb/usr/bin/
-rwxrwxrwx root/root      3364 2026-09-30 03:20 ./var/jb/usr/bin/cboptimize
drwxrwxrwx root/root         0 2026-09-29 15:43 ./var/jb/usr/lib/
drwxrwxrwx root/root         0 2026-10-01 07:31 ./var/jb/usr/lib/ellekit/
-rwxrwxrwx root/root     67552 2026-10-01 07:31 ./var/jb/usr/lib/ellekit/OldABI.dylib
drwxr-xr-x root/root         0 2026-10-01 07:33 ./var/jb/usr/libexec/
-rwxrwxrwx root/root    150528 2026-10-01 07:33 ./var/jb/usr/libexec/cboptimize_helper
```

</details>

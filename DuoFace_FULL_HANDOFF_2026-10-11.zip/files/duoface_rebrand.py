from pathlib import Path
from PIL import Image, ImageOps
import os, re, plistlib, subprocess
root=Path('/mnt/data/duoface_work'); app=root/'var/jb/Applications/DuoNaviUI.app'; assets=root/'var/jb/Library/Application Support/DuoNavi'
mock=Image.open('/mnt/data/a_clean_high_resolution_graphic_design_mockup_on.png').convert('RGB'); icon=Image.open('/mnt/data/a_sleek_high_contrast_cinematic_stylized_digital.png').convert('RGB')
# Exact artwork, no re-generation. Wide panel contains its own design; crop whitespace only.
wide=mock.crop((0,170,1217,615)); square=mock.crop((1218,0,1983,765))
wide=ImageOps.contain(wide,(940,225),Image.Resampling.LANCZOS); bg=Image.new('RGB',(960,240),'black');bg.paste(wide,((960-wide.width)//2,(240-wide.height)//2));bg.save(assets/'duonavi-logo.png')
square.resize((640,640),Image.Resampling.LANCZOS).save(assets/'duonavi-logo-vert.png')
icon.resize((256,256),Image.Resampling.LANCZOS).save(assets/'duonavi-icon.png')
for f in app.glob('AppIcon*.png'):
 from PIL import Image as I
 old=I.open(f); target=old.size
 icon.resize(target,I.Resampling.LANCZOS).save(f)
# length preserving ASCII replacement for Mach-O binary, scripts and plist payloads
mapping=[(b'DuoNavi',b'DuoFace'),(b'duonavi',b'duoface'),(b'DUONAVI',b'DUOFACE')]
for f in root.rglob('*'):
 if not f.is_file() or f.suffix.lower()=='.png':continue
 b=f.read_bytes();new=b
 for a,z in mapping:new=new.replace(a,z)
 if new!=b:f.write_bytes(new)
# Rename paths bottom-up; names preserve lengths for embedded executable paths.
for p in sorted(root.rglob('*'),key=lambda p:len(p.parts),reverse=True):
 new=p.name.replace('DuoNavi','DuoFace').replace('duonavi','duoface').replace('DUONAVI','DUOFACE')
 if new!=p.name:p.rename(p.with_name(new))
# Remove stale third-party branding URLs instead of implying they belong to new brand.
ctrl=root/'DEBIAN/control';s=ctrl.read_text();s=re.sub(r'^SileoDepiction:.*\n','',s,flags=re.M);s=re.sub(r'^Icon:.*\n','',s,flags=re.M);s=s.replace('Maintainer: DuoFace Team <support@duoface.com>','Maintainer: DuoFace Team');ctrl.write_text(s)
print('Files:',len([p for p in root.rglob('*') if p.is_file()]))

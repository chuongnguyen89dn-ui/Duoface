# DUOFACE — TIẾP TỤC DỰ ÁN
Cập nhật: 2026-10-11
Repository đích: chuongnguyen89dn-ui/duoface (CHƯA TẠO trên GitHub)

## Mục tiêu bắt buộc
- Rebrand DuoNavi 1.0.3 thành DuoFace, giữ nguyên toàn bộ chức năng CarPlay/split-screen.
- Package ID: com.duoface.app; bundle ID dự kiến com.duoface.duofaceui; icon hai mặt trắng/đen, chữ DuoFace, slogan TWO FACES ONE SCREEN.
- Cài độc lập; không gỡ, thay thế, ghi đè gói DuoNavi. Không tự ý loại bỏ bất kỳ thành phần gốc nào khi chưa kiểm tra phụ thuộc.
- Tự ghi nhật ký công việc, bản dựng, log, thay đổi, kết quả và việc tiếp theo trong repo này.

## Hiện trạng xác nhận trên thiết bị
- iPhone jailbreak rootless; cơ sở dữ liệu dpkg tại /var/jb/Library/dpkg.
- Bản 1.0.3-4 và 1.0.3-5: sau khi thử cài, `sudo dpkg-query -s com.duoface.app` hiển thị `Status: install ok not-installed`.
- Không có biểu tượng DuoFace trên iPhone và không hiện như gói đã cài trong Sileo.
- Chưa có log lỗi cài đặt đầy đủ; không được khẳng định nguyên nhân chính xác.
- Chưa có bằng chứng 1.0.3-6 cài/chạy thành công.

## Các bản DEB có trong môi trường làm việc (chưa đẩy GitHub)
- DuoFace_1.0.3-4_FULL_COPY_UNSIGNED_TEST.deb
- DuoFace_1.0.3-5_ROOTLESS_SAFE_TEST.deb
- DuoFace_1.0.3-6_FULL_PAYLOAD_ROOTLESS_UNVERIFIED.deb
- DuoNavi_1.0.3_5years_UNSIGNED_TEST.deb và các tài liệu/phụ kiện DuoNavi khác.
LƯU Ý: file '5years' là bản thử nghiệm chỉnh sửa, không được coi là bản gốc phát hành hoặc giấy phép đã xác minh.

## Lịch sử thay đổi và sai sót
- 1.0.3-4: cấu trúc file theo var/jb/...; đã thử cài, không được dpkg ghi nhận là installed.
- 1.0.3-5: loại bỏ OldABI.dylib, cboptimize, cboptimize_helper, cấu hình sudoers và script postinst/prerm; thay đường dẫn thành Applications/... và Library/.... Đây là quyết định không được người dùng yêu cầu, không có xác minh phụ thuộc.
- 1.0.3-6: được giới thiệu là khôi phục payload từ bản 4, song chưa có xác minh thực tế về cài đặt, chữ ký, hoạt động và độc lập.
- Các nhận định trước đây về nguyên nhân lỗi chỉ là giả thuyết; không được ghi thành kết luận.

## Việc tiếp theo
1. Xác định chính xác file DEB phát hành DuoNavi gốc, phân biệt với các bản patch thử nghiệm.
2. Lập inventory, hash, metadata, control scripts, paths, Mach-O install names và entitlement của từng file, đối chiếu với DuoFace.
3. Giữ toàn bộ chức năng, chỉ thay đổi các định danh/đường dẫn thực sự cần thiết; tránh đụng chạm thành phần hệ thống dùng chung.
4. Kiểm tra gói bằng dpkg-deb, ký mã phù hợp với jailbreak rootless; xác nhận script cài đặt không làm thay đổi DuoNavi.
5. Lấy lỗi cài đặt chính xác qua Sileo log nếu vẫn thất bại; kiểm tra dpkg status, uicache, rồi mới thử CarPlay thực tế.
6. Cập nhật tài liệu này mỗi khi có kết quả, commit, bản build hoặc thay đổi.

## Trạng thái bàn giao
Tài liệu này được tạo trong môi trường ChatGPT, CHƯA được commit lên GitHub do repo đích chưa tồn tại và kết nối GitHub hiện tại không cung cấp chức năng tạo repo.
